# README

```
$ cd cs50.readthedocs.io
$ cli50
$ make # then visit http://localhost:8080/
```
