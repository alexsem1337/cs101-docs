# `cs50/ide`

`cs50/ide` is the [Docker](../../docker) image on [Docker Hub](https://hub.docker.com/r/cs50/ide), implemented with this [`Dockerfile`](https://github.com/cs50/ide/blob/main/Dockerfile), used by [CS50 IDE](../ide/index).
