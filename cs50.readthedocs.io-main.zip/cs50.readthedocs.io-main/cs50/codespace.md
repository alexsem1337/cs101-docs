# `cs50/codespace`

`cs50/codespace` is the [Docker](../../docker) image on [Docker Hub](https://hub.docker.com/r/cs50/codespace), implemented with this [`Dockerfile`](https://github.com/cs50/codespace/blob/main/Dockerfile), used by CS50's adaptation of [Visual Studio Code](/code/). It is also available as `ghcr.io/cs50/codespace` on [GitHub Packages](https://github.com/cs50/codespace/pkgs/container/codespace).
