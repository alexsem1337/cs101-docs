# `cs50/check`

`cs50/check` is the [Docker](../../docker) image on [Docker Hub](https://hub.docker.com/r/cs50/check), implemented with this [`Dockerfile`](https://github.com/cs50/check/blob/main/Dockerfile) used by [submit.cs50.io](https://submit.cs50.io/) to run [`check50`](https://cs50.readthedocs.io/projects/check50/).
