# `cs50/cli`

`cs50/cli` is the [Docker](../../docker) image on [Docker Hub](https://hub.docker.com/r/cs50/cli), implemented with this [`Dockerfile`](https://github.com/cs50/cli/blob/main/Dockerfile), used by [`cli50`](../cli50).
