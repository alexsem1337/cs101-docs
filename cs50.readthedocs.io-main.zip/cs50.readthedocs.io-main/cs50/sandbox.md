# `cs50/sandbox`

`cs50/sandbox` is a [Docker](../../docker) image on [Docker Hub](https://hub.docker.com/r/cs50/sandbox), implemented with this [`Dockerfile`](https://github.com/cs50/sandbox/blob/main/Dockerfile), with which you can create a container nearly identical to those used by [CS50 Sandbox](../sandbox).
